<?php

namespace Database\Seeders;
// use App\Models\tikets as ModelsMuseum;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class tiket extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        // ModelsTiket::create([
        //     'id' => 1,
        //     'nama_museum' => 'Museum Keris Nusantara',
        // ]);
    }
}
